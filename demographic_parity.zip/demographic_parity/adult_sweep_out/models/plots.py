#!/usr/bin/env python3
"""
plot_fairness_scaling.py
=========================
Loads the batch_results_*.csv and batch_group_details_*.csv files produced
by dpopt.py's --folder mode (one pair per sensitive-feature combination)
and produces a full set of static PNG plots for scalability + fairness
analysis.

Expected input files (edit COMBOS below if your filenames/paths differ):
    batch_results_f0_f3.csv          batch_group_details_f0_f3.csv
    batch_results_f6_f7.csv          batch_group_details_f6_f7.csv
    batch_results_f8_f9.csv          batch_group_details_f8_f9.csv

Usage
-----
    python plot_fairness_scaling.py --data_dir ./data --out_dir ./plots

Produces (in --out_dir)
------------------------
File-level (from batch_results_*.csv), one PNG per plot, all 3 combos
together unless noted "per combo":
  01_heatmap_elapsed_<combo>.png        elapsed_s over (depth x n_trees), per combo
  02_heatmap_max_disparity_weighted_<combo>.png   same grid, weighted disparity
  03_line_elapsed_vs_trees.png          elapsed_s vs n_trees, one line per (combo, depth)
  04_line_ngroups_vs_trees.png          n_groups vs n_trees, one line per (combo, depth)
  05_disparity_unweighted_vs_weighted.png   grouped bars, all combos, largest model (T6,D3)
  06_line_elapsed_vs_depth.png          elapsed_s vs depth, one line per (combo, n_trees)

Per-group (from batch_group_details_*.csv):
  07_heatmap_empty_region_fraction_<combo>.png   empty/feasible ratio over (depth x n_trees)
  08_scatter_unweighted_vs_weighted_ratio.png     per-group ratio agreement, all combos
  09_bar_group_weighted_ratio_<combo>_T6_D3.png   per-group weighted ratio, largest model
"""

import argparse
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

# (combo_label, sensitive_features_str_as_in_csv) -- combo_label is used in
# filenames and legends; must match the "_fX_fY" suffix on your CSV files.
COMBOS = [
    ("f0_f3", "0 3", "age & marital-status"),
    ("f6_f7", "6 7", "race & sex"),
    ("f8_f9", "8 9", "capital-gain & capital-loss"),
]

COLORS = {"f0_f3": "#1f77b4", "f6_f7": "#d62728", "f8_f9": "#2ca02c"}


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------


def load_all(data_dir):
    """Returns (results_by_combo, groups_by_combo), each a dict combo_label -> DataFrame."""
    results = {}
    groups = {}
    for combo_label, _, _ in COMBOS:
        rpath = os.path.join(data_dir, f"batch_results_{combo_label}.csv")
        gpath = os.path.join(data_dir, f"batch_group_details_{combo_label}.csv")
        if not os.path.exists(rpath):
            raise FileNotFoundError(f"Missing: {rpath}")
        if not os.path.exists(gpath):
            raise FileNotFoundError(f"Missing: {gpath}")
        results[combo_label] = pd.read_csv(rpath)
        groups[combo_label] = pd.read_csv(gpath)
    return results, groups


# ---------------------------------------------------------------------------
# Helper: pivot a results dataframe into a (depth x n_trees) grid
# ---------------------------------------------------------------------------


def pivot_grid(df, value_col):
    """Returns (matrix, depths_sorted, trees_sorted) for imshow-style plotting."""
    pivot = df.pivot(index="depth", columns="n_trees", values=value_col)
    pivot = pivot.sort_index().sort_index(axis=1)
    return pivot.values, list(pivot.index), list(pivot.columns)


def _heatmap(
    matrix,
    row_labels,
    col_labels,
    title,
    xlabel,
    ylabel,
    filepath,
    fmt=".1f",
    cmap="YlOrRd",
    cbar_label="",
    log_color=False,
):
    nrows, ncols = len(row_labels), len(col_labels)
    fig, ax = plt.subplots(figsize=(max(5, ncols * 1.3), max(3, nrows * 1.0)))

    if log_color:
        valid = matrix[~np.isnan(matrix) & (matrix > 0)]
        vmin = valid.min() if len(valid) else 1e-3
        vmax = valid.max() if len(valid) else 1.0
        norm = mcolors.LogNorm(vmin=vmin, vmax=vmax)
    else:
        valid = matrix[~np.isnan(matrix)]
        vmin = valid.min() if len(valid) else 0
        vmax = valid.max() if len(valid) else 1
        norm = mcolors.Normalize(vmin=vmin, vmax=vmax)

    cmap_obj = plt.get_cmap(cmap).copy()
    cmap_obj.set_bad("#e0e0e0")

    im = ax.imshow(matrix, aspect="auto", cmap=cmap_obj, norm=norm)
    ax.set_xticks(range(ncols))
    ax.set_xticklabels(col_labels)
    ax.set_yticks(range(nrows))
    ax.set_yticklabels(row_labels)
    ax.set_xlabel(xlabel, fontsize=11)
    ax.set_ylabel(ylabel, fontsize=11)
    ax.set_title(title, fontsize=12, pad=10)

    for i in range(nrows):
        for j in range(ncols):
            val = matrix[i, j]
            if np.isnan(val):
                txt = "--"
            else:
                txt = format(val, fmt)
            ax.text(j, i, txt, ha="center", va="center", fontsize=9, color="black")

    plt.colorbar(im, ax=ax, label=cbar_label, shrink=0.85)
    plt.tight_layout()
    plt.savefig(filepath, dpi=150)
    plt.close(fig)
    print(f"  Saved: {filepath}")


# ---------------------------------------------------------------------------
# Plot 1 + 2: per-combo heatmaps of elapsed_s and max_disparity_weighted
# ---------------------------------------------------------------------------


def plot_heatmaps_per_combo(results, out_dir):
    for combo_label, _, combo_desc in COMBOS:
        df = results[combo_label]

        matrix, depths, trees = pivot_grid(df, "elapsed_s")
        _heatmap(
            matrix,
            [str(d) for d in depths],
            [str(t) for t in trees],
            title=f"Verification Time (s) -- {combo_desc} ({combo_label})",
            xlabel="Number of Trees",
            ylabel="Depth",
            filepath=os.path.join(out_dir, f"01_heatmap_elapsed_{combo_label}.png"),
            fmt=".2f",
            cmap="YlOrRd",
            cbar_label="seconds",
            log_color=True,
        )

        matrix, depths, trees = pivot_grid(df, "max_disparity_weighted")
        _heatmap(
            matrix,
            [str(d) for d in depths],
            [str(t) for t in trees],
            title=f"Max Weighted Disparity -- {combo_desc} ({combo_label})",
            xlabel="Number of Trees",
            ylabel="Depth",
            filepath=os.path.join(
                out_dir, f"02_heatmap_max_disparity_weighted_{combo_label}.png"
            ),
            fmt=".3f",
            cmap="RdYlGn_r",
            cbar_label="max disparity (weighted)",
        )


# ---------------------------------------------------------------------------
# Plot 3: elapsed_s vs n_trees, one line per (combo, depth)
# ---------------------------------------------------------------------------


def plot_elapsed_vs_trees(results, out_dir):
    fig, axes = plt.subplots(1, len(COMBOS), figsize=(6 * len(COMBOS), 5), sharey=True)
    if len(COMBOS) == 1:
        axes = [axes]

    for ax, (combo_label, _, combo_desc) in zip(axes, COMBOS):
        df = results[combo_label]
        depths = sorted(df["depth"].unique())
        colors = plt.get_cmap("viridis")(np.linspace(0, 0.85, len(depths)))
        for depth, color in zip(depths, colors):
            sub = df[df["depth"] == depth].sort_values("n_trees")
            ax.plot(
                sub["n_trees"],
                sub["elapsed_s"],
                marker="o",
                color=color,
                label=f"depth={depth}",
            )
        ax.set_yscale("log")
        ax.set_xlabel("Number of Trees")
        ax.set_title(f"{combo_desc}\n({combo_label})", fontsize=11)
        ax.grid(True, alpha=0.3, which="both")
        ax.legend(fontsize=8)

    axes[0].set_ylabel("Verification Time (s), log scale")
    fig.suptitle("Verification Time vs Number of Trees", fontsize=13)
    plt.tight_layout()
    fp = os.path.join(out_dir, "03_line_elapsed_vs_trees.png")
    plt.savefig(fp, dpi=150)
    plt.close(fig)
    print(f"  Saved: {fp}")


# ---------------------------------------------------------------------------
# Plot 4: n_groups vs n_trees, one line per (combo, depth)
# ---------------------------------------------------------------------------


def plot_ngroups_vs_trees(results, out_dir):
    fig, ax = plt.subplots(figsize=(8, 5))
    for combo_label, _, combo_desc in COMBOS:
        df = results[combo_label]
        # use the largest available depth for a clean single comparable line per combo
        max_depth = df["depth"].max()
        sub = df[df["depth"] == max_depth].sort_values("n_trees")
        ax.plot(
            sub["n_trees"],
            sub["n_groups"],
            marker="o",
            color=COLORS[combo_label],
            label=f"{combo_desc} (depth={max_depth})",
        )
    ax.set_xlabel("Number of Trees")
    ax.set_ylabel("Number of Groups (n_groups)")
    ax.set_title(
        "Sensitive-Feature Group Count vs Number of Trees\n(at each combo's deepest depth tested)"
    )
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    fp = os.path.join(out_dir, "04_line_ngroups_vs_trees.png")
    plt.savefig(fp, dpi=150)
    plt.close(fig)
    print(f"  Saved: {fp}")


# ---------------------------------------------------------------------------
# Plot 5: unweighted vs weighted disparity, grouped bars, largest model per combo
# ---------------------------------------------------------------------------


def plot_disparity_comparison(results, out_dir):
    labels = []
    unweighted = []
    weighted = []
    for combo_label, _, combo_desc in COMBOS:
        df = results[combo_label]
        row = df.loc[
            df["n_trees"].idxmax()
        ]  # largest n_trees row (ties broken by max depth via sort below)
        # prefer the row with both max n_trees AND max depth
        row = df.sort_values(["n_trees", "depth"]).iloc[-1]
        labels.append(
            f"{combo_desc}\n({combo_label})\nT{int(row.n_trees)} D{int(row.depth)}"
        )
        unweighted.append(row["max_disparity_unweighted"])
        weighted.append(row["max_disparity_weighted"])

    x = np.arange(len(labels))
    width = 0.35
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar(x - width / 2, unweighted, width, label="Unweighted", color="#9ecae1")
    ax.bar(x + width / 2, weighted, width, label="Weighted", color="#fd8d3c")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_ylabel("Max Disparity")
    ax.set_title("Unweighted vs Weighted Max Disparity (largest model per combo)")
    ax.axhline(0.1, color="gray", linestyle="--", linewidth=1, label="epsilon=0.1")
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3, axis="y")
    plt.tight_layout()
    fp = os.path.join(out_dir, "05_disparity_unweighted_vs_weighted.png")
    plt.savefig(fp, dpi=150)
    plt.close(fig)
    print(f"  Saved: {fp}")


# ---------------------------------------------------------------------------
# Plot 6: elapsed_s vs depth, one line per (combo, n_trees)
# ---------------------------------------------------------------------------


def plot_elapsed_vs_depth(results, out_dir):
    fig, axes = plt.subplots(1, len(COMBOS), figsize=(6 * len(COMBOS), 5), sharey=True)
    if len(COMBOS) == 1:
        axes = [axes]

    for ax, (combo_label, _, combo_desc) in zip(axes, COMBOS):
        df = results[combo_label]
        trees_vals = sorted(df["n_trees"].unique())
        colors = plt.get_cmap("plasma")(np.linspace(0, 0.85, len(trees_vals)))
        for nt, color in zip(trees_vals, colors):
            sub = df[df["n_trees"] == nt].sort_values("depth")
            ax.plot(
                sub["depth"],
                sub["elapsed_s"],
                marker="o",
                color=color,
                label=f"trees={nt}",
            )
        ax.set_yscale("log")
        ax.set_xlabel("Depth")
        ax.set_title(f"{combo_desc}\n({combo_label})", fontsize=11)
        ax.grid(True, alpha=0.3, which="both")
        ax.legend(fontsize=7, ncol=2)

    axes[0].set_ylabel("Verification Time (s), log scale")
    fig.suptitle("Verification Time vs Depth", fontsize=13)
    plt.tight_layout()
    fp = os.path.join(out_dir, "06_line_elapsed_vs_depth.png")
    plt.savefig(fp, dpi=150)
    plt.close(fig)
    print(f"  Saved: {fp}")


# ---------------------------------------------------------------------------
# Plot 7: per-combo heatmap of empty-region fraction over (depth x n_trees)
# ---------------------------------------------------------------------------


def plot_empty_region_fraction(groups, out_dir):
    for combo_label, _, combo_desc in COMBOS:
        gdf = groups[combo_label]
        # one row per file already repeats feasible/empty across its groups identically,
        # so dedupe to one row per (n_trees, depth) before pivoting
        file_level = gdf.drop_duplicates(subset=["filename", "n_trees", "depth"]).copy()
        file_level["empty_fraction"] = (
            file_level["empty_regions"] / file_level["feasible_regions_total"]
        )
        matrix, depths, trees = pivot_grid(
            file_level[["n_trees", "depth", "empty_fraction"]], "empty_fraction"
        )
        _heatmap(
            matrix,
            [str(d) for d in depths],
            [str(t) for t in trees],
            title=f"Empty-Region Fraction -- {combo_desc} ({combo_label})\n"
            f"(fraction of feasible symbolic regions with NO matching data rows)",
            xlabel="Number of Trees",
            ylabel="Depth",
            filepath=os.path.join(
                out_dir, f"07_heatmap_empty_region_fraction_{combo_label}.png"
            ),
            fmt=".2f",
            cmap="Purples",
            cbar_label="empty / feasible",
        )


# ---------------------------------------------------------------------------
# Plot 8: scatter of unweighted vs weighted ratio, all groups, all combos
# ---------------------------------------------------------------------------


def plot_unweighted_vs_weighted_scatter(groups, out_dir):
    fig, ax = plt.subplots(figsize=(7, 7))
    for combo_label, _, combo_desc in COMBOS:
        gdf = groups[combo_label]
        sub = gdf.dropna(subset=["unweighted_ratio", "weighted_ratio"])
        ax.scatter(
            sub["unweighted_ratio"],
            sub["weighted_ratio"],
            s=25,
            alpha=0.6,
            color=COLORS[combo_label],
            label=combo_desc,
        )
    ax.plot(
        [0, 1],
        [0, 1],
        color="gray",
        linestyle="--",
        linewidth=1,
        label="y = x (perfect agreement)",
    )
    ax.set_xlabel("Unweighted positive ratio")
    ax.set_ylabel("Weighted positive ratio")
    ax.set_title(
        "Per-Group Agreement: Unweighted vs Weighted Positive Ratio\n"
        "(points far from the diagonal = symbolic counting and real data disagree)"
    )
    ax.set_xlim(-0.05, 1.05)
    ax.set_ylim(-0.05, 1.05)
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    fp = os.path.join(out_dir, "08_scatter_unweighted_vs_weighted_ratio.png")
    plt.savefig(fp, dpi=150)
    plt.close(fig)
    print(f"  Saved: {fp}")


# ---------------------------------------------------------------------------
# Plot 9: per-group weighted ratio bar chart for the largest model, per combo
# ---------------------------------------------------------------------------


def plot_per_group_bars_largest_model(groups, out_dir):
    for combo_label, _, combo_desc in COMBOS:
        gdf = groups[combo_label]
        max_nt = gdf["n_trees"].max()
        max_depth = gdf.loc[gdf["n_trees"] == max_nt, "depth"].max()
        sub = gdf[(gdf["n_trees"] == max_nt) & (gdf["depth"] == max_depth)].copy()
        sub = sub.sort_values("weighted_ratio", na_position="first")

        if len(sub) == 0:
            continue

        fig, ax = plt.subplots(figsize=(9, max(4, 0.35 * len(sub))))
        is_na = sub["weighted_ratio"].isna()
        # NaN rows (no dataset rows matched this group at all -- weighted_total=0)
        # get a small fixed-width grey placeholder bar so they're visibly
        # distinguishable from a real ratio of 0.0, rather than disappearing
        # as a zero-width bar (which is indistinguishable from "not plotted").
        plot_vals = sub["weighted_ratio"].copy()
        placeholder_width = 0.02
        plot_vals[is_na] = placeholder_width
        colors = ["#bdbdbd" if na else "#fd8d3c" for na in is_na]
        ax.barh(range(len(sub)), plot_vals, color=colors)
        ax.set_yticks(range(len(sub)))
        ax.set_yticklabels(sub["group_name"], fontsize=7)
        ax.set_xlabel("Weighted positive ratio")
        ax.set_title(
            f"Per-Group Weighted Positive Ratio -- {combo_desc} ({combo_label})\n"
            f"Largest model: T{int(max_nt)} D{int(max_depth)}  (grey = no matching data)",
            fontsize=10,
        )
        ax.set_xlim(0, 1.0)
        ax.grid(True, alpha=0.3, axis="x")
        plt.tight_layout()
        fp = os.path.join(
            out_dir,
            f"09_bar_group_weighted_ratio_{combo_label}_T{int(max_nt)}_D{int(max_depth)}.png",
        )
        plt.savefig(fp, dpi=150)
        plt.close(fig)
        print(f"  Saved: {fp}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main(args):
    os.makedirs(args.out_dir, exist_ok=True)
    print(f"Loading CSVs from: {args.data_dir}")
    results, groups = load_all(args.data_dir)

    for combo_label, _, _ in COMBOS:
        print(
            f"  {combo_label}: {len(results[combo_label])} file-level rows, "
            f"{len(groups[combo_label])} group-level rows"
        )

    print("\nGenerating plots...")
    plot_heatmaps_per_combo(results, args.out_dir)
    plot_elapsed_vs_trees(results, args.out_dir)
    plot_ngroups_vs_trees(results, args.out_dir)
    plot_disparity_comparison(results, args.out_dir)
    plot_elapsed_vs_depth(results, args.out_dir)
    plot_empty_region_fraction(groups, args.out_dir)
    plot_unweighted_vs_weighted_scatter(groups, args.out_dir)
    plot_per_group_bars_largest_model(groups, args.out_dir)

    print(f"\nAll plots saved to: {args.out_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Plot fairness-verification scalability analysis."
    )
    parser.add_argument(
        "--data_dir",
        default=".",
        help="Directory containing the 6 input CSVs (default: .)",
    )
    parser.add_argument(
        "--out_dir",
        default="./plots",
        help="Directory to write PNG plots (default: ./plots)",
    )
    args = parser.parse_args()
    main(args)
