#!/usr/bin/env python3
"""
dpopt.py — Symbolic Fairness Verification
          epsilon-Demographic Parity (unweighted and weighted)
          for XGBoost decision tree ensembles via Z3 SMT solver.

Usage examples
--------------
Single file:
  python dpopt.py model_T5_D3.json --sensitive_features 7 8 --epsilon 0.1

Batch folder:
  python dpopt.py --folder ./models --sensitive_features 7 8 --epsilon 0.1
                  --dataset adult.csv --out_dir ./results
                  --max_seconds_per_file 1800

Preview group counts across all feature combos:
  python dpopt.py --preview_groups model_T5_D3.json --details bounds.csv
"""

import sys
import re
import os
import argparse
import time
import traceback
import multiprocessing as mp

import pandas as pd
import numpy as np
import z3

# ---------------------------------------------------------------------------
# XGBoost model loader
# ---------------------------------------------------------------------------


def open_model_xgb(filepath, max_trees=None):
    """
    Parse an XGBoost model stored as JSON or PKL and return a flat
    DataFrame of tree nodes together with metadata.

    Returns
    -------
    trees       : pd.DataFrame  columns: Tree, Node, ID, Feature, Split,
                                          Yes, No, Gain
    n_trees     : int
    n_features  : int
    """
    ext = os.path.splitext(filepath)[1].lower()

    if ext == ".json":
        import json

        with open(filepath) as fh:
            raw = json.load(fh)
        # XGBoost dump_model(dump_format='json') produces a list of trees
        # each tree is a nested dict with keys: nodeid, depth, split,
        # split_condition, yes, no, missing, children / leaf
        rows = []
        for tree_idx, tree_obj in enumerate(raw):
            if max_trees is not None and tree_idx >= max_trees:
                break
            _parse_xgb_json_tree(tree_obj, tree_idx, rows)
        trees = pd.DataFrame(rows)

    elif ext in (".pkl", ".pickle"):
        import pickle

        with open(filepath, "rb") as fh:
            booster = pickle.load(fh)
        # Accept either a raw Booster or a fitted sklearn wrapper
        if hasattr(booster, "get_booster"):
            booster = booster.get_booster()
        trees = _xgb_booster_to_df(booster, max_trees)

    else:
        raise ValueError(f"Unsupported file extension: {ext}")

    n_trees = int(trees["Tree"].max()) + 1
    feat_ids = [int(f[1:]) for f in trees["Feature"].unique() if f != "Leaf"]
    n_features = max(feat_ids) + 1 if feat_ids else 0
    return trees, n_trees, n_features


def _parse_xgb_json_tree(node, tree_idx, rows):
    """Recursively flatten one XGBoost JSON tree into rows."""
    node_id = node["nodeid"]
    uid = f"{tree_idx}_{node_id}"
    if "leaf" in node:
        rows.append(
            {
                "Tree": tree_idx,
                "Node": node_id,
                "ID": uid,
                "Feature": "Leaf",
                "Split": None,
                "Yes": None,
                "No": None,
                "Gain": float(node["leaf"]),
            }
        )
    else:
        feat = f"f{node['split']}" if str(node["split"]).isdigit() else node["split"]
        rows.append(
            {
                "Tree": tree_idx,
                "Node": node_id,
                "ID": uid,
                "Feature": feat,
                "Split": float(node["split_condition"]),
                "Yes": f"{tree_idx}_{node['yes']}",
                "No": f"{tree_idx}_{node['no']}",
                "Gain": 0.0,
            }
        )
        for child in node.get("children", []):
            _parse_xgb_json_tree(child, tree_idx, rows)


def _xgb_booster_to_df(booster, max_trees=None):
    """Convert an XGBoost Booster to the same flat DataFrame format."""
    import json

    dump = booster.get_dump(dump_format="json")
    rows = []
    for tree_idx, tree_str in enumerate(dump):
        if max_trees is not None and tree_idx >= max_trees:
            break
        _parse_xgb_json_tree(json.loads(tree_str), tree_idx, rows)
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Region weight computation
# ---------------------------------------------------------------------------


def compute_region_weights(df, all_thresholds):
    """
    Assign each row in df to a symbolic region (identified by a bool-tuple
    of threshold comparisons) and count rows per region.

    Returns
    -------
    region_weights : dict  key -> int (number of dataset rows in region)
    bit_columns    : list of (feature_idx, threshold) in sorted order
    """
    if df is None or len(df) == 0:
        return {}, []

    working = df.copy()
    bit_columns = []

    for feat_idx in sorted(all_thresholds):
        col = f"f{feat_idx}"
        if col not in working.columns:
            continue
        for t in sorted(all_thresholds[feat_idx]):
            bcol = f"bit_f{feat_idx}_{t}"
            working[bcol] = working[col].to_numpy() < t
            bit_columns.append((feat_idx, t))

    if not bit_columns:
        return {(): len(working)}, []

    bcol_names = [f"bit_f{fi}_{t}" for fi, t in bit_columns]
    grouped = working[bcol_names].groupby(bcol_names).size().reset_index(name="count")
    region_weights = {}
    for _, row in grouped.iterrows():
        key = tuple(bool(row[c]) for c in bcol_names)
        region_weights[key] = int(row["count"])
    return region_weights, bit_columns


# ---------------------------------------------------------------------------
# Z3 variable / constraint builders
# ---------------------------------------------------------------------------


def make_bits_for_features(trees, vars_, op_range_list):
    """
    Create ordered Boolean threshold-indicator variables f_i_<split> for
    every split threshold in the ensemble, and add ordering constraints
    (if f_i < t1 then f_i < t2 for t1 < t2).
    """
    ord_cons = []
    feat_ids = sorted(
        {
            int(row.Feature[1:])
            for row in trees.itertuples(index=False)
            if row.Feature != "Leaf"
        }
    )
    for fi in feat_ids:
        splits = sorted(trees[trees["Feature"] == f"f{fi}"]["Split"].dropna().unique())
        prev = False
        for split in splits:
            v = z3.Bool(f"f{fi}_{split}")
            ord_cons.append(z3.Implies(prev, v))
            vars_[f"f{fi}_{split}"] = v
            prev = v
    return ord_cons


def get_feature_bit(vars_, feat_idx, split, op_range_list):
    lb, ub = op_range_list[feat_idx]
    if split <= lb:
        return z3.BoolVal(False)
    if split > ub:
        return z3.BoolVal(True)
    return vars_[f"f{feat_idx}_{split}"]


def gen_pb_cons_tree(tree_df, vars_, op_range_list, precision):
    """
    Encode one tree as pseudo-Boolean constraints.
    Returns (constraint_list, list of (bool_var, int_score) for leaves).
    """
    cons = []
    leaf_scores = []
    root = tree_df[tree_df["Node"] == 0].iloc[0]
    cons.append(vars_[root.ID])

    for row in tree_df.itertuples(index=False):
        v = vars_[row.ID]
        if row.Feature == "Leaf":
            leaf_scores.append((v, int(round(row.Gain * precision))))
            continue
        cond = get_feature_bit(
            vars_, int(row.Feature[1:]), float(row.Split), op_range_list
        )
        cons.append(vars_[row.Yes] == z3.And(v, cond))
        cons.append(vars_[row.No] == z3.And(v, z3.Not(cond)))

    leaf_nodes = [
        (1, vars_[row.ID])
        for row in tree_df.itertuples(index=False)
        if row.Feature == "Leaf"
    ]
    cons.append(z3.PbEq(leaf_nodes, 1))
    return cons, leaf_scores


# ---------------------------------------------------------------------------
# Incremental model counter (OPT: blocking-clause enumeration)
# ---------------------------------------------------------------------------


def count_models_incremental(
    base_solver, extra_constraints, projection_vars, timeout_ms=None
):
    """
    Count satisfying assignments by iterating with blocking clauses.
    Returns -1 on timeout.
    """
    base_solver.push()
    for c in extra_constraints:
        base_solver.add(c)

    count = 0
    t_start = time.time()
    while True:
        if timeout_ms is not None:
            if (time.time() - t_start) * 1000 >= timeout_ms:
                count = -1
                break
        if base_solver.check() != z3.sat:
            break
        m = base_solver.model()
        count += 1
        base_solver.add(
            z3.Or([v != m.eval(v, model_completion=True) for v in projection_vars])
        )

    base_solver.pop()
    return count


# ---------------------------------------------------------------------------
# Single-pass region enumeration (used for weighted DP)
# ---------------------------------------------------------------------------


def enumerate_regions_single_pass(
    base_solver, positive_output, projection_vars, vars_, bit_columns, timeout_ms=None
):
    """
    Enumerate all satisfying assignments once, recording for each region
    (a) its bit-key and (b) whether it is positively classified.
    Returns list of (key_tuple, is_positive_bool).
    """
    base_solver.push()
    regions = []
    t_start = time.time()
    while True:
        if timeout_ms is not None and (time.time() - t_start) * 1000 >= timeout_ms:
            break
        if base_solver.check() != z3.sat:
            break
        m = base_solver.model()
        key = tuple(
            bool(m.eval(vars_[f"f{fi}_{t}"], model_completion=True))
            for fi, t in bit_columns
        )
        is_pos = bool(m.eval(positive_output, model_completion=True))
        regions.append((key, is_pos))
        base_solver.add(
            z3.Or([v != m.eval(v, model_completion=True) for v in projection_vars])
        )
    base_solver.pop()
    return regions


# ---------------------------------------------------------------------------
# Region matcher for weighted counting
# ---------------------------------------------------------------------------


def build_col_index(bit_columns):
    return {(fi, t): idx for idx, (fi, t) in enumerate(bit_columns)}


def make_region_matcher(raw_intervals, col_index):
    """
    Returns a function that tests whether a region key (bool-tuple)
    satisfies the interval constraints of one fairness group.
    """

    def matches(key):
        for feat_idx, left, right in raw_intervals:
            if left is not None:
                idx = col_index.get((feat_idx, left))
                if idx is not None and key[idx]:
                    return False
            if right is not None:
                idx = col_index.get((feat_idx, right))
                if idx is not None and not key[idx]:
                    return False
        return True

    return matches


# ---------------------------------------------------------------------------
# Disparity helpers
# ---------------------------------------------------------------------------


def max_pairwise(values):
    """Maximum absolute pairwise difference among a list of floats."""
    best = 0.0
    n = len(values)
    for i in range(n):
        for j in range(i + 1, n):
            d = abs(values[i] - values[j])
            if d > best:
                best = d
    return best


# ---------------------------------------------------------------------------
# Core verification: epsilon-DP and weighted epsilon-DP
# ---------------------------------------------------------------------------


def verify_demographic_parity(
    sensitive_features,
    epsilon,
    threshold,
    precision,
    trees,
    n_trees,
    op_range_list,
    dataset=None,
    timeout_per_group_s=None,
):
    """
    Verify epsilon-demographic parity (unweighted) and, if a dataset is
    provided, weighted epsilon-demographic parity.

    Parameters
    ----------
    sensitive_features    : list of int   feature indices
    epsilon               : float         fairness tolerance
    threshold             : float         classification threshold tau
    precision             : int           score scaling for Z3 int arithmetic
    trees                 : pd.DataFrame  flat tree table from open_model_xgb
    n_trees               : int
    op_range_list         : list of (lb, ub) per feature
    dataset               : pd.DataFrame or None
    timeout_per_group_s   : float or None

    Returns
    -------
    dict with keys:
      use_weights, fair_unweighted, max_disparity_unweighted,
      fair_weighted, max_disparity_weighted, groups
    """
    use_weights = dataset is not None
    timeout_ms = timeout_per_group_s * 1000 if timeout_per_group_s else None

    # ── Build Z3 variables and base solver ──────────────────────────────
    vars_ = {}
    ord_cons = make_bits_for_features(trees, vars_, op_range_list)

    all_thresholds = {}
    sensitive_thresholds = {f: set() for f in sensitive_features}

    for row in trees.itertuples(index=False):
        vars_[row.ID] = z3.Bool(f"node_{row.ID}")
        if row.Feature == "Leaf":
            continue
        fi = int(row.Feature[1:])
        split = float(row.Split)
        all_thresholds.setdefault(fi, set()).add(split)
        if fi in sensitive_thresholds:
            sensitive_thresholds[fi].add(split)

    for fi in all_thresholds:
        all_thresholds[fi] = sorted(all_thresholds[fi])

    projection_vars = [
        v for k, v in vars_.items() if isinstance(k, str) and k.startswith("f")
    ]

    base_solver = z3.Solver()
    base_solver.add(ord_cons)

    all_leaf_scores = []
    tree_groups = {k: v for k, v in trees.groupby("Tree", sort=False)}
    for tree_idx in range(n_trees):
        cons, leaf_scores = gen_pb_cons_tree(
            tree_groups[tree_idx], vars_, op_range_list, precision
        )
        base_solver.add(cons)
        all_leaf_scores.extend(leaf_scores)

    score_expr = z3.Sum([z3.If(lv, s, 0) for lv, s in all_leaf_scores])
    positive_output = score_expr >= int(threshold * precision)

    # ── Dataset weights ──────────────────────────────────────────────────
    region_weights = {}
    bit_columns = []
    col_index = {}
    all_valid_regions = None

    if use_weights:
        region_weights, bit_columns = compute_region_weights(dataset, all_thresholds)
        col_index = build_col_index(bit_columns)
        if bit_columns:
            all_valid_regions = enumerate_regions_single_pass(
                base_solver,
                positive_output,
                projection_vars,
                vars_,
                bit_columns,
                timeout_ms=timeout_ms,
            )

    # ── Build group constraints ──────────────────────────────────────────
    feature_groups = []  # Z3 constraints per feature
    feature_groups_raw = []  # raw interval specs per feature

    for f in sensitive_features:
        thresholds = sorted(sensitive_thresholds[f])
        if not thresholds:
            feature_groups.append([("unused", z3.BoolVal(True))])
            feature_groups_raw.append([("unused", [])])
            continue

        lb, ub = op_range_list[f]
        bounds = [lb] + thresholds + [ub]
        z3_grps, raw_grps = [], []

        for i in range(len(bounds) - 1):
            left, right = bounds[i], bounds[i + 1]
            z3_cons, raw_cons = [], []
            if i > 0:
                z3_cons.append(z3.Not(get_feature_bit(vars_, f, left, op_range_list)))
                raw_cons.append((f, left, None))
            if i < len(bounds) - 2:
                z3_cons.append(get_feature_bit(vars_, f, right, op_range_list))
                raw_cons.append((f, None, right))
            if not z3_cons:
                z3_cons = [z3.BoolVal(True)]

            label = f"f{f} in [{left}, {right})"
            z3_grps.append((label, z3.And(z3_cons)))
            raw_grps.append((label, raw_cons))

        feature_groups.append(z3_grps)
        feature_groups_raw.append(raw_grps)

    from itertools import product as iproduct

    group_names = []
    group_constraints = []
    group_raw_ivs = []

    for combo_z3, combo_raw in zip(
        iproduct(*feature_groups), iproduct(*feature_groups_raw)
    ):
        names, z3cons, raw_ivs = [], [], []
        for (name, c), (_, rc) in zip(combo_z3, combo_raw):
            names.append(name)
            z3cons.append(c)
            raw_ivs.extend(rc)
        group_names.append(" AND ".join(names))
        group_constraints.append(z3.And(z3cons))
        group_raw_ivs.append(raw_ivs)

    # ── Per-group verification ───────────────────────────────────────────
    group_results = {}
    unweighted_ratios = []
    weighted_ratios = []

    n_groups = len(group_names)
    n_skipped = 0
    n_timed_out = 0

    for group_name, group_cons, raw_ivs in zip(
        group_names, group_constraints, group_raw_ivs
    ):
        # Quick UNSAT check — skip empty groups
        base_solver.push()
        base_solver.add(group_cons)
        feasible = base_solver.check()
        base_solver.pop()

        if feasible == z3.unsat:
            n_skipped += 1
            group_results[group_name] = {
                "group_status": "skipped_unsat",
                "total_regions": 0,
                "positive_regions": 0,
                "unweighted_ratio": 0.0,
                "weighted_total": None,
                "weighted_positive": None,
                "weighted_ratio": None,
                "dataset_rows": len(dataset) if use_weights else None,
                "feasible_regions_total": 0,
                "non_empty_regions": 0,
                "empty_regions": 0,
            }
            unweighted_ratios.append(0.0)
            weighted_ratios.append(None)
            continue

        # ── Unweighted DP: Z3 model counting ────────────────────────────
        total_regions = count_models_incremental(
            base_solver, [group_cons], projection_vars, timeout_ms=timeout_ms
        )
        positive_regions = count_models_incremental(
            base_solver,
            [group_cons, positive_output],
            projection_vars,
            timeout_ms=timeout_ms,
        )

        if total_regions == -1 or positive_regions == -1:
            n_timed_out += 1
            group_results[group_name] = {
                "group_status": "timed_out",
                "total_regions": total_regions,
                "positive_regions": positive_regions,
                "unweighted_ratio": None,
                "weighted_total": None,
                "weighted_positive": None,
                "weighted_ratio": None,
                "dataset_rows": len(dataset) if use_weights else None,
                "feasible_regions_total": None,
                "non_empty_regions": None,
                "empty_regions": None,
            }
            unweighted_ratios.append(None)
            weighted_ratios.append(None)
            continue

        unweighted_ratio = (
            positive_regions / total_regions if total_regions > 0 else 0.0
        )

        # ── Weighted DP: dataset-based counting ─────────────────────────
        weighted_total = None
        weighted_positive = None
        weighted_ratio = None
        non_empty = 0
        empty = 0

        if use_weights and all_valid_regions is not None:
            matcher = make_region_matcher(raw_ivs, col_index)
            wt, wp = 0, 0
            for bit_key, is_pos in all_valid_regions:
                if not matcher(bit_key):
                    continue
                w = region_weights.get(bit_key, 0)
                if w > 0:
                    non_empty += 1
                    wt += w
                    if is_pos:
                        wp += w
                else:
                    empty += 1
            weighted_total = wt
            weighted_positive = wp
            weighted_ratio = wp / wt if wt > 0 else 0.0

        group_results[group_name] = {
            "group_status": "ok",
            "total_regions": total_regions,
            "positive_regions": positive_regions,
            "unweighted_ratio": unweighted_ratio,
            "weighted_total": weighted_total,
            "weighted_positive": weighted_positive,
            "weighted_ratio": weighted_ratio,
            "dataset_rows": len(dataset) if use_weights else None,
            "feasible_regions_total": total_regions,
            "non_empty_regions": non_empty if use_weights else None,
            "empty_regions": empty if use_weights else None,
        }
        unweighted_ratios.append(unweighted_ratio)
        weighted_ratios.append(weighted_ratio)

    # ── Compute disparities ──────────────────────────────────────────────
    valid_uw = [r for r in unweighted_ratios if r is not None]
    max_disp_uw = max_pairwise(valid_uw) if len(valid_uw) >= 2 else 0.0

    valid_w = [r for r in weighted_ratios if r is not None]
    max_disp_w = (
        max_pairwise(valid_w)
        if (use_weights and len(valid_w) >= 2)
        else (0.0 if use_weights else None)
    )

    return {
        "use_weights": use_weights,
        "fair_unweighted": max_disp_uw <= epsilon,
        "max_disparity_unweighted": max_disp_uw,
        "fair_weighted": (max_disp_w <= epsilon) if use_weights else None,
        "max_disparity_weighted": max_disp_w,
        "n_groups": n_groups,
        "n_groups_skipped": n_skipped,
        "n_groups_timed_out": n_timed_out,
        "groups": group_results,
    }


# ---------------------------------------------------------------------------
# Model + bounds loader
# ---------------------------------------------------------------------------


def load_trees_and_bounds(filepath, args):
    """
    Load model from JSON/PKL, optionally load feature bounds CSV and dataset.

    Returns
    -------
    trees, n_trees, n_features, op_range_list, dataset
    """
    trees, n_trees, n_features = open_model_xgb(filepath, max_trees=args.max_trees)

    # Expand op_range_list if bounds file references more features
    n_feat = n_features
    details_df = None
    if args.details and os.path.exists(args.details):
        details_df = pd.read_csv(args.details)
        if len(details_df):
            n_feat = max(n_features, int(details_df["feature"].max()) + 1)

    op_range_list = [(-(10**8), 10**8)] * n_feat

    if args.details:
        if not os.path.exists(args.details):
            raise FileNotFoundError(f"Bounds file not found: {args.details}")
        if details_df is None:
            details_df = pd.read_csv(args.details)
        for _, row in details_df.iterrows():
            i = int(row["feature"])
            op_range_list[i] = (float(row["lb"]), float(row["ub"]))

    dataset = None
    if args.dataset:
        if not os.path.exists(args.dataset):
            raise FileNotFoundError(f"Dataset file not found: {args.dataset}")
        dataset = pd.read_csv(args.dataset)
        # Rename columns to f0, f1, ... if not already named that way
        if not any(c.startswith("f") and c[1:].isdigit() for c in dataset.columns):
            dataset.columns = [f"f{i}" for i in range(len(dataset.columns))]

    return trees, n_trees, n_features, op_range_list, dataset


# ---------------------------------------------------------------------------
# Group count preview (no solver calls)
# ---------------------------------------------------------------------------


def count_groups_for_features(trees, sensitive_features, op_range_list):
    s_thresh = {f: set() for f in sensitive_features}
    for row in trees.itertuples(index=False):
        if row.Feature == "Leaf":
            continue
        fi = int(row.Feature[1:])
        if fi in s_thresh:
            s_thresh[fi].add(float(row.Split))
    G = 1
    per_feat = {}
    for f in sensitive_features:
        n = len(s_thresh[f])
        g = 1 if n == 0 else n + 1
        per_feat[f] = g
        G *= g
    return G, per_feat


# ---------------------------------------------------------------------------
# CSV output helpers
# ---------------------------------------------------------------------------

FILENAME_PATTERN = re.compile(
    r"^.+_T(?P<n_trees>\d+)_D(?P<depth>\d+)\.(json|pkl|pickle)$",
    re.IGNORECASE,
)


def _feat_suffix(sensitive_features):
    return "f" + "_f".join(str(f) for f in sensitive_features)


def _fmt(v, decimals=6):
    if v is None:
        return None
    if isinstance(v, float):
        return round(v, decimals)
    return v


def build_results_row(
    filename, n_trees, depth, status, elapsed, result, sensitive_features, epsilon
):
    """One row for batch_results_<feat>.csv"""
    sf = sensitive_features
    base = {
        "filename": filename,
        "n_trees": n_trees,
        "depth": depth,
        "status": status,
        "elapsed_s": round(elapsed, 3) if elapsed is not None else None,
    }
    if result is None:
        base.update(
            {
                "fair_unweighted": None,
                "max_disparity_unweighted": None,
                "fair_weighted": None,
                "max_disparity_weighted": None,
                "n_sensitive_features": len(sf),
                "n_groups": None,
                "n_groups_skipped": None,
                "n_groups_timed_out": None,
                "total_regions_sum": None,
                "total_regions_max": None,
                "positive_regions_sum": None,
            }
        )
        return base

    groups = result.get("groups", {})
    ok_groups = [g for g in groups.values() if g["group_status"] == "ok"]
    tr_list = [g["total_regions"] for g in ok_groups if g["total_regions"] is not None]
    pr_list = [
        g["positive_regions"] for g in ok_groups if g["positive_regions"] is not None
    ]

    base.update(
        {
            "fair_unweighted": result.get("fair_unweighted"),
            "max_disparity_unweighted": _fmt(result.get("max_disparity_unweighted")),
            "fair_weighted": result.get("fair_weighted"),
            "max_disparity_weighted": _fmt(result.get("max_disparity_weighted")),
            "n_sensitive_features": len(sf),
            "n_groups": result.get("n_groups"),
            "n_groups_skipped": result.get("n_groups_skipped"),
            "n_groups_timed_out": result.get("n_groups_timed_out"),
            "total_regions_sum": sum(tr_list) if tr_list else None,
            "total_regions_max": max(tr_list) if tr_list else None,
            "positive_regions_sum": sum(pr_list) if pr_list else None,
        }
    )
    return base


def build_group_detail_rows(filename, n_trees, depth, result, sensitive_features):
    """Rows for batch_group_details_<feat>.csv"""
    rows = []
    if result is None:
        return rows

    sf_str = " ".join(str(f) for f in sensitive_features)
    # Number of groups per first sensitive feature (for column)
    first_f = sensitive_features[0]
    groups = result.get("groups", {})

    for gidx, (group_name, stats) in enumerate(groups.items(), 1):
        rows.append(
            {
                "filename": filename,
                "n_trees": n_trees,
                "depth": depth,
                "n_sensitive_features": len(sensitive_features),
                "sensitive_features": sf_str,
                f"feature_{first_f}_groups": len(
                    [k for k in groups if True]  # total groups
                ),
                "group_index": gidx,
                "group_name": group_name,
                "group_status": stats.get("group_status"),
                "total_regions": stats.get("total_regions"),
                "positive_regions": stats.get("positive_regions"),
                "unweighted_ratio": _fmt(stats.get("unweighted_ratio")),
                "weighted_total": stats.get("weighted_total"),
                "weighted_positive": stats.get("weighted_positive"),
                "weighted_ratio": _fmt(stats.get("weighted_ratio")),
                "dataset_rows": stats.get("dataset_rows"),
                "feasible_regions_total": stats.get("feasible_regions_total"),
                "non_empty_regions": stats.get("non_empty_regions"),
                "empty_regions": stats.get("empty_regions"),
            }
        )
    return rows


# ---------------------------------------------------------------------------
# Single-file worker (runs in subprocess for timeout enforcement)
# ---------------------------------------------------------------------------


def _worker(filepath, args, conn):
    """
    Runs in a subprocess. Loads the model, runs verification, and sends
    the result back through a Pipe connection (more reliable for
    delivering a single payload than a Queue, which can race with
    process exit).
    """
    try:
        trees, n_trees, n_features, op_range_list, dataset = load_trees_and_bounds(
            filepath, args
        )

        t0 = time.time()
        result = verify_demographic_parity(
            sensitive_features=args.sensitive_features,
            epsilon=args.epsilon,
            threshold=args.threshold,
            precision=args.precision,
            trees=trees,
            n_trees=n_trees,
            op_range_list=op_range_list,
            dataset=dataset,
            timeout_per_group_s=getattr(args, "timeout_per_group", None),
        )
        elapsed = time.time() - t0
        conn.send(("ok", elapsed, result, n_trees, n_features))
    except Exception:
        conn.send(("error", traceback.format_exc(), None, None, None))
    finally:
        conn.close()


def run_single_with_timeout(filepath, args, max_seconds):
    """
    Runs verify_demographic_parity in a subprocess with a hard wall-clock
    timeout. Uses a Pipe (not a Queue) so that the parent can safely
    block on poll()/recv() and is guaranteed to see the payload if the
    child finished before the timeout, avoiding the race where a Queue
    appears empty immediately after the child process exits.
    """
    parent_conn, child_conn = mp.Pipe(duplex=False)
    p = mp.Process(target=_worker, args=(filepath, args, child_conn), daemon=True)
    p.start()
    child_conn.close()  # parent doesn't write to this end

    t_start = time.time()
    if parent_conn.poll(timeout=max_seconds):
        # Data arrived before the timeout — read it, then let the
        # process exit naturally (it already finished its work).
        try:
            status, v1, v2, v3, v4 = parent_conn.recv()
        except EOFError:
            status, v1, v2, v3, v4 = (
                "error",
                "Worker exited without sending a result.",
                None,
                None,
                None,
            )
        p.join(timeout=max(0.0, max_seconds - (time.time() - t_start)))
        if p.is_alive():
            p.terminate()
            p.join(timeout=5)
            if p.is_alive():
                p.kill()
                p.join()
        parent_conn.close()

        if status == "ok":
            return "ok", v1, v2, v3, v4
        else:
            print(f"  [ERROR]\n{v1}")
            return "error", 0.0, None, None, None

    # No data arrived within max_seconds — genuine timeout.
    if p.is_alive():
        p.terminate()
        p.join(timeout=5)
        if p.is_alive():
            p.kill()
            p.join()
    parent_conn.close()
    return "timeout", float(max_seconds), None, None, None


# ---------------------------------------------------------------------------
# Pretty-print for single-file mode
# ---------------------------------------------------------------------------


def print_result(filepath, n_trees, n_features, args, result, elapsed):
    use_w = result["use_weights"]
    print("\n" + "=" * 60)
    print("Symbolic Fairness Verification — epsilon-Demographic Parity")
    print("=" * 60)
    print(f"  Model              : {filepath}")
    print(f"  Trees              : {n_trees}")
    print(f"  Features           : {n_features}")
    print(f"  Sensitive features : {args.sensitive_features}")
    print(f"  Threshold (tau)    : {args.threshold}")
    print(f"  Epsilon            : {args.epsilon}")
    print(f"  Weighted mode      : {'yes (' + args.dataset + ')' if use_w else 'no'}")
    print("=" * 60)

    uw = result["max_disparity_unweighted"]
    fw = result["fair_unweighted"]
    print(
        f"\n[Unweighted DP]  {'FAIR' if fw else 'UNFAIR'}"
        f"   max Delta_DP = {uw:.6f}   (epsilon = {args.epsilon})"
    )

    if use_w and result["max_disparity_weighted"] is not None:
        w = result["max_disparity_weighted"]
        fw2 = result["fair_weighted"]
        print(
            f"[Weighted   DP]  {'FAIR' if fw2 else 'UNFAIR'}"
            f"   max Delta_DP = {w:.6f}   (epsilon = {args.epsilon})"
        )

    print(
        f"\nGroups : {result['n_groups']}  "
        f"skipped : {result['n_groups_skipped']}  "
        f"timed out : {result['n_groups_timed_out']}"
    )
    print()

    for name, stats in result["groups"].items():
        status = stats["group_status"]
        print(f"  {name}")
        if status == "skipped_unsat":
            print("    [SKIP — empty group (UNSAT)]\n")
            continue
        if status == "timed_out":
            print("    [TIMED OUT]\n")
            continue
        tr = stats["total_regions"]
        pr = stats["positive_regions"]
        ur = stats["unweighted_ratio"]
        print(f"    total regions    : {tr}")
        print(f"    positive regions : {pr}")
        print(f"    unweighted ratio : {ur:.6f}")
        if use_w and stats["weighted_ratio"] is not None:
            print(f"    weighted total   : {stats['weighted_total']}")
            print(f"    weighted positive: {stats['weighted_positive']}")
            print(f"    weighted ratio   : {stats['weighted_ratio']:.6f}")
        elif use_w:
            print("    weighted ratio   : (region absent from dataset)")
        print()

    print(f"Verification time : {elapsed:.4f} s")
    print("=" * 60 + "\n")


# ---------------------------------------------------------------------------
# Batch mode
# ---------------------------------------------------------------------------


def discover_model_files(folder, args):
    entries = []
    for fname in sorted(os.listdir(folder)):
        m = FILENAME_PATTERN.match(fname)
        if not m:
            continue
        n_trees = int(m.group("n_trees"))
        depth = int(m.group("depth"))
        if args.min_trees and n_trees < args.min_trees:
            continue
        if args.max_trees_filter and n_trees > args.max_trees_filter:
            continue
        if args.min_depth and depth < args.min_depth:
            continue
        if args.max_depth_filter and depth > args.max_depth_filter:
            continue
        entries.append(
            {
                "path": os.path.join(folder, fname),
                "filename": fname,
                "n_trees": n_trees,
                "depth": depth,
            }
        )
    entries.sort(key=lambda e: (e["depth"], e["n_trees"]))
    return entries


def run_batch(args):
    folder = args.folder
    if not os.path.isdir(folder):
        print(f"[ERROR] Not a directory: {folder}")
        sys.exit(1)

    entries = discover_model_files(folder, args)
    if not entries:
        print(f"No matching model files found in {folder}.")
        sys.exit(1)

    if not args.dataset:
        print("[INFO] --dataset not provided. " "Only unweighted DP will be computed.")
    else:
        print(f"[INFO] Dataset: {args.dataset} (weighted DP enabled)")

    out_dir = args.out_dir if args.out_dir else folder
    os.makedirs(out_dir, exist_ok=True)

    suffix = _feat_suffix(args.sensitive_features)
    results_path = os.path.join(out_dir, f"batch_results_{suffix}.csv")
    details_path = os.path.join(out_dir, f"batch_group_details_{suffix}.csv")

    print(f"\nFound {len(entries)} model file(s) — sorted (depth, n_trees).")
    print(f"Results CSV  : {results_path}")
    print(f"Details CSV  : {details_path}\n")

    result_rows = []
    detail_rows = []

    # Pruning: skip (n_trees, depth) combos dominated by a timed-out pair
    timeout_pairs = []

    def is_dominated(n_trees, depth):
        for nt, d in timeout_pairs:
            if n_trees >= nt and depth >= d:
                return nt, d
        return None

    def flush():
        pd.DataFrame(result_rows).to_csv(results_path, index=False)
        pd.DataFrame(detail_rows).to_csv(details_path, index=False)

    for entry in entries:
        filename = entry["filename"]
        n_trees = entry["n_trees"]
        depth = entry["depth"]
        filepath = entry["path"]

        # Pruning check
        if not args.no_pruning:
            dom = is_dominated(n_trees, depth)
            if dom:
                print(
                    f"[SKIP PRUNED] {filename}  "
                    f"(dominated by timeout at T={dom[0]},D={dom[1]})"
                )
                result_rows.append(
                    build_results_row(
                        filename,
                        n_trees,
                        depth,
                        "skipped_pruned",
                        None,
                        None,
                        args.sensitive_features,
                        args.epsilon,
                    )
                )
                flush()
                continue

        print(f"[RUN] {filename}  (T={n_trees}, D={depth}) ... ", end="", flush=True)
        t_wall = time.time()
        status, elapsed, result, _, _ = run_single_with_timeout(
            filepath, args, args.max_seconds_per_file
        )
        t_wall = time.time() - t_wall
        print(f"{status.upper()}  ({elapsed:.2f}s)")

        result_rows.append(
            build_results_row(
                filename,
                n_trees,
                depth,
                status,
                elapsed,
                result,
                args.sensitive_features,
                args.epsilon,
            )
        )
        detail_rows.extend(
            build_group_detail_rows(
                filename, n_trees, depth, result, args.sensitive_features
            )
        )
        flush()

        if status == "timeout" and not args.no_pruning:
            timeout_pairs.append((n_trees, depth))
            print(f"  [PRUNE] recorded timeout at (T={n_trees}, D={depth})")

    # Summary
    df = pd.DataFrame(result_rows)
    print(f"\n{'='*50}")
    print(f"Batch complete — {len(entries)} files.")
    for s in ["ok", "timeout", "error", "skipped_pruned"]:
        n = (df["status"] == s).sum()
        if n:
            print(f"  {s:20s}: {n}")
    print(f"Results : {results_path}")
    print(f"Details : {details_path}")


# ---------------------------------------------------------------------------
# Preview mode (no solver — just counts groups)
# ---------------------------------------------------------------------------


def run_preview(args):
    from itertools import combinations

    filepath = args.preview_groups
    if not os.path.exists(filepath):
        print(f"[ERROR] File not found: {filepath}")
        sys.exit(1)

    trees, n_trees, n_features, op_range_list, _ = load_trees_and_bounds(filepath, args)

    print(f"Model: {filepath}  n_trees={n_trees}  n_features={n_features}")

    max_size = args.max_combo_size
    rows = []
    for size in range(1, max_size + 1):
        for combo in combinations(range(len(op_range_list)), size):
            G, pf = count_groups_for_features(trees, list(combo), op_range_list)
            rows.append(
                {
                    "feature_indices": " ".join(str(f) for f in combo),
                    "n_features": size,
                    "n_groups": G,
                    "per_feature_groups": str(pf),
                }
            )

    df = pd.DataFrame(rows).sort_values(["n_features", "n_groups"])
    out_dir = args.out_dir if args.out_dir else "."
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "preview_groups.csv")
    df.to_csv(out_path, index=False)
    print(f"\nSaved: {out_path}")
    print("\nCheapest 10:")
    print(df.head(10).to_string(index=False))
    print("\nMost expensive 10:")
    print(df.tail(10).to_string(index=False))


# ---------------------------------------------------------------------------
# Single-file mode (CLI entry)
# ---------------------------------------------------------------------------


def run_single_file(args):
    filepath = args.filenum
    trees, n_trees, n_features, op_range_list, dataset = load_trees_and_bounds(
        filepath, args
    )

    if dataset is None and args.dataset:
        print(f"[WARN] --dataset provided but file not found: {args.dataset}")

    t0 = time.time()
    result = verify_demographic_parity(
        sensitive_features=args.sensitive_features,
        epsilon=args.epsilon,
        threshold=args.threshold,
        precision=args.precision,
        trees=trees,
        n_trees=n_trees,
        op_range_list=op_range_list,
        dataset=dataset,
        timeout_per_group_s=args.timeout_per_group,
    )
    elapsed = time.time() - t0
    print_result(filepath, n_trees, n_features, args, result, elapsed)


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------


def build_parser():
    p = argparse.ArgumentParser(
        description=(
            "Symbolic epsilon-Demographic Parity verification "
            "for XGBoost decision tree ensembles via Z3."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Modes (mutually exclusive)
    mode = p.add_mutually_exclusive_group()
    mode.add_argument(
        "filenum",
        nargs="?",
        default=None,
        help="Path to a single JSON or PKL model file.",
    )
    mode.add_argument(
        "--folder",
        type=str,
        default=None,
        metavar="DIR",
        help="Directory of model files named *_T<n>_D<d>.{json,pkl}. "
        "Runs batch verification over all matching files.",
    )
    mode.add_argument(
        "--preview_groups",
        type=str,
        default=None,
        metavar="MODEL_FILE",
        help="Print/save group counts for all feature combinations "
        "(no solver calls).",
    )

    # Required for verification
    p.add_argument(
        "--sensitive_features",
        type=int,
        nargs="+",
        default=None,
        metavar="IDX",
        help="Feature indices to treat as sensitive (e.g. 7 8).",
    )
    p.add_argument(
        "--epsilon",
        type=float,
        required=True,
        help="Fairness tolerance epsilon >= 0.",
    )

    # Model / encoding
    p.add_argument(
        "--threshold",
        type=float,
        default=0.0,
        help="Classification threshold tau (prediction positive iff score >= tau).",
    )
    p.add_argument(
        "--precision",
        type=int,
        default=100,
        help="Integer scaling factor for leaf scores in Z3 arithmetic.",
    )
    p.add_argument(
        "--max_trees",
        type=int,
        default=None,
        help="Maximum number of trees to load from the model.",
    )
    p.add_argument(
        "--details",
        type=str,
        default=None,
        metavar="CSV",
        help="CSV with columns [feature, name, lb, ub] giving feature "
        "bounds for symbolic encoding.",
    )

    # Dataset (enables weighted DP)
    p.add_argument(
        "--dataset",
        type=str,
        default=None,
        metavar="CSV",
        help="Dataset CSV with feature columns f0, f1, … "
        "Enables weighted epsilon-DP. "
        "Column names are auto-renamed to f0,f1,… if needed.",
    )

    # Timeouts
    p.add_argument(
        "--timeout_per_group",
        type=float,
        default=None,
        metavar="SECONDS",
        help="Per-group Z3 timeout in seconds.",
    )
    p.add_argument(
        "--max_seconds_per_file",
        type=float,
        default=1800.0,
        metavar="SECONDS",
        help="Wall-clock timeout per model file in batch mode.",
    )

    # Batch filters
    p.add_argument("--min_trees", type=int, default=None)
    p.add_argument("--max_trees_filter", type=int, default=None)
    p.add_argument("--min_depth", type=int, default=None)
    p.add_argument("--max_depth_filter", type=int, default=None)
    p.add_argument(
        "--no_pruning",
        action="store_true",
        help="Disable dominance-based pruning of (n_trees, depth) pairs "
        "that previously timed out.",
    )

    # Preview
    p.add_argument(
        "--max_combo_size",
        type=int,
        default=2,
        help="Maximum number of features in a combination for --preview_groups.",
    )

    # Output
    p.add_argument(
        "--out_dir",
        type=str,
        default=None,
        metavar="DIR",
        help="Directory for output CSVs. Defaults to --folder or '.'.",
    )

    return p


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main():
    parser = build_parser()
    args = parser.parse_args()

    # Mode dispatch
    if args.preview_groups:
        if args.details is None:
            print(
                "[WARN] --details not provided; feature bounds default to [-1e8, 1e8]."
            )
        run_preview(args)
        return

    if not args.sensitive_features:
        parser.error("--sensitive_features is required.")

    if args.folder:
        run_batch(args)
    elif args.filenum:
        run_single_file(args)
    else:
        parser.error("Provide a model file path, --folder, or --preview_groups.")


if __name__ == "__main__":
    mp.set_start_method("spawn", force=True)
    main()
